module.exports = {
    beforeEach: browser =>{
        browser.url("https://devmountain-qa.github.io/employee-manager/1.0_Version/index.html")
        .waitForElementPresent("#root",5000)
        browser
        .getText("p#noEmployee",results =>{
            browser.verify.ok("No Employee Selected"===results.value,'Checks that no employee is selected on page load')
            console.log(results.value);
        })
    },

    after: browser =>{
        browser.end()
    },

    'Check for invalid length inputs for the Name field.':browser =>{
        //https://dmutah.atlassian.net/browse/Q9R-46
        browser
            .click('li[name="employee7"]')
            .verify.containsText('p#employeeTitle','Ruby Estrada')
            .clearValue('input[name="nameEntry"]')
            .setValue('input[name="nameEntry"]','Ruby Estrada Joobu Jose Javier Martinez')
            .click('button#saveBtn')
            .pause(20000)
            //.verify.attributeContains('input[name="nameEntry"]','class',' invalidInfo','Name input field error check')
           // .useXpath()
           // .expect.element('/html/body/div/div/div[2]/div[2]/div[2]/span').to.be.equal('The name field must be between 1 and 30 characters long. The title field must be between 1 and 30 characters long.')
    },
}