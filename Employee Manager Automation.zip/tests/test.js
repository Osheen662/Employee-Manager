module.exports = {
    beforeEach: browser => {
        browser.url("https://devmountain-qa.github.io/employee-manager/1.1_Version/index.html")
        .waitForElementPresent("#root",10000)
        browser
            .getText("p#noEmployee", results => {
                browser.verify.ok("No Employee Selected" === results.value, 'Checks that no employee is selected on page load')
                //console.log(results.value);
            })
    },

    after: browser => {
        browser.end()
    },

    'Test Script 19 : Error Message persists from one employee to another, once an name number field throws an error and turns red, any data after that is not saved': browser =>{
        //https://dmutah.atlassian.net/browse/Q9R-55
        //https://dmutah.atlassian.net/browse/Q9R-56  ------>Bug report
        browser
            .click('li[name="employee7"]')
            .verify.containsText('p#employeeTitle', 'Ruby Estrada')
            .clearValue('input[name="nameEntry"]')
            .setValue('input[name="nameEntry"]', '12536ruhdt12536ruhdt12536ruhdt12536ruhdt12536ruhdt12536ruhdt')
            .click('button#saveBtn')
            .verify.attributeContains('input[name="nameEntry"]', 'class', ' invalidInfo', 'Phone number input field error check')
            .useXpath()
            browser.verify.containsText('/html/body/div/div/div[2]/div[2]/div[2]/span', 'The name field must be between 1 and 30 characters long.')
            .useCss()
            .click('li[name="employee5"]')
            .setValue('input[name="nameEntry"]', 'Berry')
            .click('button#saveBtn')
            .verify.containsText('p#employeeTitle', 'Dollie Berry')//The data is not updated even after valid data type and length is entered
            .verify.attributeContains('input[name="nameEntry"]','class','invalidInfo','Name  input field error check')//The field should not be red anymore, but it is
    },

}